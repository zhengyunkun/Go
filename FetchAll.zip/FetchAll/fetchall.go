package main

import (
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"time"
)

func main() {
	start := time.Now()
	ch := make(chan string)

	for num, url := range os.Args[1:] {
		go fetch(url, ch, num) //start a goroutine
	}

	for range os.Args[1:] {
		fmt.Println(<-ch) //receive from channel ch
	}

	fmt.Printf("%.2fs    elapsed\n", time.Since(start).Seconds())
}

func fetch(url string, ch chan<- string, num int) {
	start := time.Now()
	resp, err := http.Get(url)
	if err != nil {
		ch <- fmt.Sprint(err) //send to channel
		return
	}

	fileName := fmt.Sprintf("fetchResult%d.txt", num)

	//文件保存读取的内容
	outPut, err := os.Create(fileName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to create result file: %v\n", err)
		os.Exit(1)
	}
	defer outPut.Close()

	HContent, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Fprintf(os.Stderr, "fetch: %v\n", err)
		os.Exit(1)
	}

	//将读取的内容存入文件
	_, err = outPut.Write(HContent)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to write to result file: %v\n", err)
		os.Exit(1)
	}

	nbytes, err := io.Copy(ioutil.Discard, resp.Body)
	resp.Body.Close()

	if err != nil {
		ch <- fmt.Sprintf("while reading %s: %v", url, err)
		return
	}

	secs := time.Since(start).Seconds()
	ch <- fmt.Sprintf("%.2fs  %7d  %s", secs, nbytes, url)
}